import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class TrackingSimulatorTest {

    @Test
    fun addShipment() {
    }

    @Test
    fun updateShipment() {
    }

    @Test
    fun runSimulation() {
    }
}