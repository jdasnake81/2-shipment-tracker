import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class TrackerViewHelperTest {

    @Test
    fun getShipmentID() {
    }

    @Test
    fun getShipmentNotes() {
    }

    @Test
    fun getShipmentUpdateHistory() {
    }

    @Test
    fun getShipmentETA() {
    }

    @Test
    fun getShipmentStatus() {
    }

    @Test
    fun getShipmentLocation() {
    }

    @Test
    fun getVerified() {
    }

    @Test
    fun notifyUpdateAdded() {
    }

    @Test
    fun notifyNoteAdded() {
    }

    @Test
    fun notifyStatusChanged() {
    }

    @Test
    fun notifyETAChangeTimestamp() {
    }

    @Test
    fun expectedDeliveryToDate() {
    }

    @Test
    fun notifyLocationChange() {
    }

    @Test
    fun trackShipment() {
    }

    @Test
    fun stopTracking() {
    }
}