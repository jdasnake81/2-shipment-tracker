import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class ShippingUpdateTest {

    @Test
    fun getStatusChange() {
    }

    @Test
    fun testToString() {
    }
}