package updateStrategy

import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class CreatedUpdateStrategyTest {

    @Test
    fun createUpdate() {
    }
}