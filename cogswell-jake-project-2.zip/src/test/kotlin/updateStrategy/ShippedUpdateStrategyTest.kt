package updateStrategy

import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class ShippedUpdateStrategyTest {

    @Test
    fun createUpdate() {
    }
}